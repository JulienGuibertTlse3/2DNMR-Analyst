# bmp 0.3.1
* minor version update with doc fixes for CRAN

# bmp 0.3
* only warn if excess bytes noted (#2)
* doc polishing

# bmp 0.2
* Add ability to read 32 bit ARGB images

# bmp 0.1
* first version on CRAN
